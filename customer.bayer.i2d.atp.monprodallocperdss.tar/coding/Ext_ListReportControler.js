/***
@controller Name:sap.suite.ui.generic.template.ListReport.view.ListReport,
*@viewId:i2d.atp.monprodallocperdss1::sap.suite.ui.generic.template.ListReport.view.ListReport::C_MntrProdAllocPeriods
*/
sap.ui.define(
    [
      "sap/ui/core/mvc/ControllerExtension",
      "sap/m/MessageToast",
      "sap/m/MessageBox",
      "sap/m/MessageItem",
      "sap/m/MessageView",
      "sap/m/Dialog",
      "sap/m/Button",
      "sap/ui/model/Filter",
      "sap/ui/model/FilterOperator",
      // ,'sap/ui/core/mvc/OverrideExecution'
    ],
    function (
      ControllerExtension,
      MessageToast,
      MessageBox,
      MessageItem,
      MessageView,
      Dialog,
      Button,
      Filter,
      FilterOperator
      // ,OverrideExecution
    ) {
      "use strict";
      return ControllerExtension.extend(
        "customer.bayer.i2d.atp.monprodallocperdss.Ext_ListReportControler",
        {
          aChangedTransferCells: [],
          aChangedRecordCells: [],
          aTransferNotAllowerdSalesOffice: [
            "BBNE",
            "BSDO",
            "BPLA",
            "BPLO",
            "BGGD",
            "BCHA",
            "BCOF",
          ],
          onLiveChangeInputTransfer: function (oEvent) {
            this.aChangedTransferCells.push(oEvent.getSource().getId());
          },
          onChangeInputTransfer: function (oEvent) {
            if (oEvent.getParameter("newValue")) {
              if (
                this.aChangedRecordCells.indexOf(oEvent.getParameter("id")) === -1
              ) {
                this.aChangedRecordCells.push(oEvent.getParameter("id"));
              }
            } else {
              this.aChangedRecordCells.splice(oEvent.getParameter("id"), 1);
            }
            if (this.aChangedRecordCells.length > 0) {
              this.byId("idExtButton_Transfer").setEnabled(true);
            } else {
              this.byId("idExtButton_Transfer").setEnabled(false);
            }
          },
          clearTransferCells: function () {
            if (this.aChangedTransferCells.length > 0) {
              let aDistinctCells = [...new Set(this.aChangedTransferCells)];
              this.aChangedTransferCells.forEach((element) => {
                this.getView().byId(element).setValue("");
              });
              this.aChangedTransferCells = [];
            }
          },
          handleTransferAction: function (oEvent) {
            sap.ui.getCore().getMessageManager().removeAllMessages();
            this.oTable = this.getView().byId(
              "i2d.atp.monprodallocperdss1::sap.suite.ui.generic.template.ListReport.view.ListReport::C_MntrProdAllocPeriods--responsiveTable"
            );
            let aRowData = this.oTable.getItems().map(function (oItem) {
              // assuming that you are using the default model
              return oItem.getBindingContext().getObject();
            });
            let aEnteredItems = aRowData.filter((item) => {
              return (
                !isNaN(item["customer.Transfer"]) &&
                item["customer.Transfer"] !== ""
              );
            });
            if (aEnteredItems.length) {
              let bErrorInValidation =
                this.validateTransferPerSameAllocObjectAndMaterial(aEnteredItems);
              if (bErrorInValidation) {
                this.showMessageView();
              } else {
                //trigger action
                this.callActionTransferQuota(aEnteredItems); //filter out the changed items
              }
            } else {
              //the button wont be enabled unless there is an entry in the transfer cells. logic in onChangeInputTransfer()
              /*  var oMessage = new sap.ui.core.message.Message({
                type: "Information",
                message: `No changes done.`,
              });
              sap.ui.getCore().getMessageManager().addMessages(oMessage);
              this.showMessageView(); */
            }
          },
  
          callActionTransferQuota: function (aRowData) {
            this.getView()
              .getModel("customer.quotaTransfer")
              .setDeferredGroups(["batchTransferQuota"]);
  
            for (let i = 0; i < aRowData.length; i++) {
              let item = aRowData[i];
              if (!isNaN(item["customer.Transfer"])) {
                this.getView()
                  .getModel("customer.quotaTransfer")
                  .callFunction("/transfer_quota", {
                    method: "POST",
                    batchGroupId: "batchTransferQuota",
                    changeSetId: "1001",
                    urlParameters: {
                      CharcValueCombinationUUID: item.CharcValueCombinationUUID,
                      ProdAllocPerdStartUTCDateTime:
                        item.ProdAllocPerdStartUTCDateTime,
                      ProductAllocationPeriodIsAged:
                        item.ProductAllocationPeriodIsAged,
                      ProductAllocationObject: item.ProductAllocationObject,
                      ProdAllocAvailableQuantity: item.ProdAllocAvailableQuantity,
                      ProdAllocCharc01: item.ProdAllocCharc01,
                      ProdAllocCharc02: item.ProdAllocCharc02,
                      ProdAllocCharc03: item.ProdAllocCharc03,
                      ProdAllocCharc04: item.ProdAllocCharc04,
                      ProdAllocCharc05: item.ProdAllocCharc05,
                      ProdAllocCharc06: item.ProdAllocCharc06,
                      ProdAllocCharc07: item.ProdAllocCharc07,
                      ProductAllocationPeriodEndDate:
                        item.ProductAllocationPeriodEndDate,
                      ProdAllocationPeriodStartDate:
                        item.ProdAllocationPeriodStartDate,
                      ProductAllocationQuantity: item.ProductAllocationQuantity,
                      ProductAllocationQuantityUnit:
                        item.ProductAllocationQuantityUnit,
                      ProdAllocAssignedQuantity: item.ProdAllocAssignedQuantity,
                      ProdAllocAssignedQuantityUnit:
                        item.ProdAllocAssignedQuantityUnit,
                      TransferQty: item["customer.Transfer"],
                    },
                  });
              }
            }
  
            this.getView()
              .getModel("customer.quotaTransfer")
              .submitChanges({
                batchGroupId: "batchTransferQuota",
                success: function (response) {
                  this._processSuccessResponseForTransferQuotaAction(response);
                }.bind(this),
                error: function (oError) {
                  this.showMessageView();
                }.bind(this),
              });
          },
  
          _geti18nText: function (textId, params) {
            if (params) {
              return this.getView()
                .getModel("i18n")
                .getResourceBundle()
                .getText(textId, params);
            } else {
              return this.getView()
                .getModel("i18n")
                .getResourceBundle()
                .getText(textId);
            }
          },
  
          _processSuccessResponseForTransferQuotaAction: function (
            response,
            data
          ) {
            this.getView().getModel().refresh();
            var that = this;
            var oMessage = new sap.ui.core.message.Message({
              type: "Success",
              message: that._geti18nText("MsgRecordsUpdatedSuccess"),
            });
            sap.ui.getCore().getMessageManager().addMessages(oMessage);
            this.showMessageView();
            this.clearTransferCells();
            //enable result column
            //this.byId("idExtCol_Result").setVisible(true)
          },
  
          validateTransferPerSameAllocObjectAndMaterial: function (
            aEnteredItems
          ) {
            let bError = false;
            let aUniqueItemsGroupByAllocObjAndMat = [
              ...new Set(
                aEnteredItems
                  //  .filter((item) => !isNaN(item["customer.Transfer"])) //filter out only those rows for which the transfer qty field is maintained
                  .map(
                    (item) =>
                      item.ProdAllocCharc05 +
                      "#" +
                      item.ProductAllocationObject +
                      "#" +
                      //RBP-26087
                      item.ProdAllocationPeriodStartDate.toDateString() +
                      "#" +
                      item.ProductAllocationPeriodEndDate.toDateString()
                  )
              ),
            ];
  
            for (let i = 0; i < aUniqueItemsGroupByAllocObjAndMat.length; i++) {
              let [
                prodcAllocChar05Value,
                productAllocationObjectValue,
                prodAllocationPeriodStartDate,
                productAllocationPeriodEndDate,
              ] = aUniqueItemsGroupByAllocObjAndMat[i].split("#");
              let aItemsForEachAlloCObjAndMaterial = aEnteredItems.filter(
                (item) => {
                  return (
                    item.ProdAllocCharc05 === prodcAllocChar05Value &&
                    item.ProductAllocationObject ===
                      productAllocationObjectValue &&
                    item.ProdAllocationPeriodStartDate.toDateString() ===
                      prodAllocationPeriodStartDate &&
                    item.ProductAllocationPeriodEndDate.toDateString() ===
                      productAllocationPeriodEndDate
                    //!isNaN(item["customer.Transfer"])
                  );
                }
              );
  
              //check transfer sum
              let nSumOfTransferValues = 0;
              aItemsForEachAlloCObjAndMaterial.forEach((item) => {
                if (
                  Number(item.ProductAllocationQuantity) +
                    Number(item["customer.Transfer"]) <
                  item.ProdAllocAssignedQuantity
                ) {
                  item["customer.TransferValueState"] = "Error";
                  bError = true;
                  var that = this;
                  var oMessage = new sap.ui.core.message.Message({
                    type: "Error",
                    message: that._geti18nText(
                      "MsgValSumOfPlannedQtyAndTransferQtyLess",
                      [
                        parseInt(prodcAllocChar05Value),
                        productAllocationObjectValue,
                      ]
                    ),
                  });
                  sap.ui.getCore().getMessageManager().addMessages(oMessage);
                } else {
                  item["customer.TransferValueState"] = "None";
                }
                //  if (!isNaN(item["customer.Transfer"])) {
                nSumOfTransferValues =
                  nSumOfTransferValues + Number(item["customer.Transfer"]);
                //  }
              });
  
              //check if less than 0
              if (nSumOfTransferValues !== 0) {
                bError = true;
                var oMessage = new sap.ui.core.message.Message({
                  type: "Error",
                  message: `Sum of Transfer quantity is not Zero for Material: ${parseInt(
                    prodcAllocChar05Value
                  )} and Allocation Object: ${productAllocationObjectValue} with the period between ${prodAllocationPeriodStartDate} and ${productAllocationPeriodEndDate}`,
                });
                sap.ui.getCore().getMessageManager().addMessages(oMessage);
              }
            }
            this.getView().getModel().updateBindings();
            return bError;
          },
  
          createMessageView: function () {
            var oMessageTemplate = new MessageItem({
              type: "{type}",
              title: "{message}",
            });
  
            this._oMessageView = new MessageView({
              showDetailsPageHeader: false,
              items: {
                path: "/",
                template: oMessageTemplate,
              },
            });
            this.oDialog = new Dialog({
              resizable: true,
              content: this._oMessageView,
              title: "Messages",
              beginButton: new Button({
                press: function () {
                  this.getParent().close();
                },
                text: "Close",
              }),
              contentHeight: "50%",
              contentWidth: "50%",
              verticalScrolling: false,
            });
            this.oDialog.setModel(
              sap.ui.getCore().getMessageManager().getMessageModel()
            );
          },
          showMessageView: function () {
            if (!this._oMessageView) {
              this.createMessageView();
            }
            sap.ui.getCore().getMessageManager().getMessageModel().refresh();
            this.oDialog.open();
          },
  
          override: {
            onInit: function () {
              this._oLocalModel = new sap.ui.model.json.JSONModel({
                extItems: [],
              });
  
              this.getView().setModel(this._oLocalModel, "customer.localModel");
            },
            onAfterRendering: function () {
              let oSmartTable = this.getView()
                .byId(
                  "i2d.atp.monprodallocperdss1::sap.suite.ui.generic.template.ListReport.view.ListReport::C_MntrProdAllocPeriods--responsiveTable"
                )
                .getParent();
              oSmartTable.getTable().attachUpdateFinished(
                function (props) {
                  let aItems = props.getSource().getItems();
                  aItems.forEach((element) => {
                    let item = element.getBindingContext().getObject();
                    let sCharValComb = item.ProdAllocCharcValCombn;
                    let bFoundNotAllowedSalesOffice = false;
                    this.aTransferNotAllowerdSalesOffice.forEach(
                      (salesOffice) => {
                        if (sCharValComb.includes(salesOffice)) {
                          bFoundNotAllowedSalesOffice = true;
                          return;
                        }
                      }
                    );
                    if (bFoundNotAllowedSalesOffice) {
                      let oTransferInputCell = element
                        .getCells()
                        .find((i) => i.getId().includes("ExtInput_Transfer"));
                      oTransferInputCell.setEnabled(false);
                    }
                  });
                }.bind(this)
              );
              oSmartTable.setProperty(
                "requestAtLeastFields",
                "ProdAllocCharc01,ProdAllocCharc02,ProdAllocCharc03,ProdAllocCharc04,ProdAllocCharc05,ProdAllocCharc06,ProdAllocCharc07,ProdAllocationPeriodStartDate,ProductAllocationPeriodEndDate,ProductAllocationQuantity,ProductAllocationQuantityUnit,ProdAllocAssignedQuantity,ProdAllocAssignedQuantityUnit"
              );
            },
            templateBaseExtension: {
              addFilters: function (fnAddFilter, sControlId) {
                var oComboBox = this.byId("idExtProdAllocObjectCBFilter");
                var sSelectedKey = oComboBox.getSelectedKey();
                var oFilter = new Filter({
                  path: "ProductAllocationObject",
                  operator: FilterOperator.EQ,
                  value1: sSelectedKey,
                });
                if (oFilter) {
                  fnAddFilter(this, oFilter);
                }
              },
            },
          },
        }
      );
    }
  );
  